setwd("C:\\Users\\User\\OneDrive\\Desktop\\2025-SEM 1\\IT2120\\Lab Sessions\\Lab 10")

#Part 01
customers <- c(55, 62, 43, 46, 50)
chisq.test(customers, p = rep(1/5, 5))

#Part 02
housetasks <- read.table("http://www.sthda.com/sthda/RDoc/data/housetasks.txt",
                         header = TRUE, row.names = 1)
housetasks
chisq.test(housetasks)
