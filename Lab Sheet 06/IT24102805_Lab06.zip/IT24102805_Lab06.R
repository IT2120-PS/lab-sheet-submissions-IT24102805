setwd("C:\\Users\\User\\OneDrive\\Desktop\\IT24102805")


# Question 1 part 1
n <- 50       
p <- 0.85     

# X ~ Binomial(n=50, p=0.85)


# Question 1 part 2
prob_ex1_q2 <- sum(dbinom(47:50, size=n, prob=p))
prob_ex1_q2


# Question 2 
lambda <- 12

#part 1
# Let X = number of calls per hour

#Part 2
 Distribution: X ~ Poisson(lambda = 12)


# Part 3
prob_ex2_q3 <- dpois(15, lambda)
prob_ex2_q3

